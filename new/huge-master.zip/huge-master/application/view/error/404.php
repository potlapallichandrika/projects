<div class="container">
    <h1>404 - Page not found</h1>
    <div class="box">
        <p class="red-text">This page does not exist.</p>
    </div>
</div>
