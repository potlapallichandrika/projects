<br></br>

<div class="content-box">
	<div class="row">
		<div class="col">
			<h4>Change Text Color</h4>
		</div>
	</div>
</div>